package task3.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import task3.DriverFactory;
import task3.pages.StoreMyInfoPage;
import task3.pages.StoreMainPage;

public class Stepdefs extends DriverFactory {
    StoreMainPage storeMainPage = new StoreMainPage(driver);
    StoreMyInfoPage info = new StoreMyInfoPage(driver);

    @Given("^I am on main page$")
    public void iAmOnMainPage() throws Throwable {
        StoreMainPage storeMainPage = new StoreMainPage(driver);
    }

    @When("^I go to log in page$")
    public void iGoToLogInPage() throws Throwable {
      storeMainPage.loginButton();}

    @And("^I fill in login field with login \"([^\"]*)\"$")
    public void iFillInLoginFieldWithLogin(String login) throws Throwable {
       storeMainPage.loginStep(login);
    }

    @And("^I fill in password field with password \"([^\"]*)\"$")
    public void iFillInPasswordFieldWithPassword(String password) throws Throwable {
        storeMainPage.sendPassword(password);
    }

    @And("^I hit button Sign in$")
    public void iHitButtonSignIn() throws Throwable {
        storeMainPage.logIn();
    }

    @And("^I log in and I click on My personal information tab$")
    public void iLogInAndIClickOnMyPersonalInformationTab() throws Throwable {
        storeMainPage.MyInfo();
    }

    @Then("^I see my personal information$")
    public void iSeeMyPersonalInformation() throws Throwable {
        info.assertInfo();
        destroyDriver();
    }

    @Then("^I see error message$")
    public void iSeeErrorMessage() throws Throwable {

        destroyDriver();
    }
}
